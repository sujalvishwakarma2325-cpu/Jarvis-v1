# JARVIS V1

Starter Android project for a personal voice assistant.

## Current V1 foundation
- Kotlin Android app
- Futuristic dark JARVIS-style interface
- Speech-to-text using Android SpeechRecognizer intent
- Text-to-speech replies
- Basic command routing
- Battery analysis
- Microphone permission handling

## Planned modules
1. AI brain / LLM API
2. Persistent memory
3. Reminders and alarms
4. Device and storage analysis
5. Android actions through supported APIs
6. Notifications integration
7. Background/wake-word functionality where Android permits
8. Voice verification
9. Multi-device sync

## Build
Open the project in Android Studio and let Gradle sync.
Then run the `app` configuration on an Android 8.0+ device/emulator.

Do not put private AI API keys directly in the APK. Use a secure backend for production.
