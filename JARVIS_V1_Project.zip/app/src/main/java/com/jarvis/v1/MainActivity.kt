package com.jarvis.v1

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.BatteryManager
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import java.util.Locale

class MainActivity : ComponentActivity(), TextToSpeech.OnInitListener {

    private lateinit var status: TextView
    private lateinit var response: TextView
    private lateinit var tts: TextToSpeech

    private val speechLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            val data = result.data
            val text = data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
            if (!text.isNullOrBlank()) handleCommand(text)
        }

    private val permissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            if (granted) listen() else {
                status.text = "Microphone permission required."
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        tts = TextToSpeech(this, this)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(40, 60, 40, 40)
            setBackgroundColor(android.graphics.Color.rgb(5, 7, 13))
        }

        val title = TextView(this).apply {
            text = "J A R V I S"
            textSize = 32f
            setTextColor(android.graphics.Color.rgb(93, 231, 255))
        }

        status = TextView(this).apply {
            text = "ONLINE • CORE V1"
            textSize = 14f
            setTextColor(android.graphics.Color.rgb(139, 166, 184))
            setPadding(0, 16, 0, 24)
        }

        response = TextView(this).apply {
            text = "Good morning. I am ready for your command."
            textSize = 20f
            setTextColor(android.graphics.Color.rgb(232, 247, 255))
            setPadding(0, 30, 0, 30)
        }

        val listen = Button(this).apply {
            text = "🎙  TALK TO JARVIS"
            textSize = 18f
            setOnClickListener {
                if (ContextCompat.checkSelfPermission(
                        this@MainActivity, Manifest.permission.RECORD_AUDIO
                    ) == PackageManager.PERMISSION_GRANTED
                ) listen()
                else permissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
            }
        }

        val battery = Button(this).apply {
            text = "CHECK BATTERY"
            setOnClickListener { showBattery() }
        }

        root.addView(title)
        root.addView(status)
        root.addView(response)
        root.addView(listen)
        root.addView(battery)
        setContentView(root)
    }

    private fun listen() {
        status.text = "LISTENING..."
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,
                RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "en-IN")
            putExtra(RecognizerIntent.EXTRA_PROMPT, "Speak to JARVIS")
        }
        speechLauncher.launch(intent)
    }

    private fun handleCommand(command: String) {
        status.text = "COMMAND RECEIVED"
        response.text = "You: $command"

        val lower = command.lowercase(Locale.getDefault())
        val reply = when {
            "battery" in lower -> batteryReply()
            "hello" in lower || "hi" in lower || "hey" in lower ->
                "Hello. JARVIS is online and ready."
            "your name" in lower -> "I am JARVIS, your personal assistant."
            else ->
                "I heard: $command. My AI action engine will be connected in the next module."
        }

        response.text = reply
        speak(reply)
    }

    private fun batteryReply(): String {
        val bm = getSystemService(BATTERY_SERVICE) as BatteryManager
        val level = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
        return "Current battery level is $level percent."
    }

    private fun showBattery() {
        val reply = batteryReply()
        response.text = reply
        speak(reply)
    }

    private fun speak(text: String) {
        tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "jarvis")
    }

    override fun onInit(statusCode: Int) {
        if (statusCode == TextToSpeech.SUCCESS) {
            tts.language = Locale("en", "IN")
            tts.setSpeechRate(0.95f)
        }
    }

    override fun onDestroy() {
        tts.stop()
        tts.shutdown()
        super.onDestroy()
    }
}
